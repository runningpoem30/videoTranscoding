export {};
//# sourceMappingURL=test-trigger.d.ts.map