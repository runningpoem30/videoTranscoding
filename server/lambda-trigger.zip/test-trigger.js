/**
 * Local test script for trigger.ts Lambda
 *
 * This simulates what happens when S3 triggers the Lambda
 * after a video is uploaded to the upload bucket.
 *
 * NOTE: This will actually attempt to start an ECS task if your
 * AWS credentials have permission. Use with caution!
 */
import { handler } from './handler/trigger.js';
import dotenv from 'dotenv';
dotenv.config();
// Simulate an S3 event (this is what S3 sends when a file is uploaded)
const mockS3Event = {
    Records: [{
            eventVersion: '2.1',
            eventSource: 'aws:s3',
            awsRegion: 'us-east-1',
            eventTime: new Date().toISOString(),
            eventName: 'ObjectCreated:Put',
            s3: {
                s3SchemaVersion: '1.0',
                bucket: {
                    name: process.env.S3_BUCKET || 'storage.zylar.space',
                    arn: 'arn:aws:s3:::storage.zylar.space'
                },
                object: {
                    key: 'video-uploads/1706456789-test-video.mp4',
                    size: 1024000,
                    eTag: 'abc123'
                }
            }
        }]
};
console.log('🚀 Testing Trigger Lambda...\n');
console.log('Simulated S3 Event:');
console.log('  Bucket:', mockS3Event.Records[0].s3.bucket.name);
console.log('  Key:', mockS3Event.Records[0].s3.object.key);
console.log('---');
// Set required env vars for ECS (use dummy values for dry-run)
const isDryRun = !process.env.SUBNETS;
if (isDryRun) {
    console.log('⚠️  DRY RUN MODE (no SUBNETS configured)');
    console.log('   Set SUBNETS and SECURITY_GROUPS env vars for real test\n');
}
handler(mockS3Event)
    .then(() => {
    console.log('\n✅ Trigger Lambda executed successfully!');
    if (!isDryRun) {
        console.log('   Check AWS Console for running ECS task.');
    }
})
    .catch((error) => {
    console.error('\n❌ Error:', error);
    console.log('\n💡 Common issues:');
    console.log('   - Missing CLUSTER env var');
    console.log('   - Missing SUBNETS/SECURITY_GROUPS env vars');
    console.log('   - IAM permissions to run ECS tasks');
});
//# sourceMappingURL=test-trigger.js.map