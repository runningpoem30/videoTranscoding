import { S3Client } from "@aws-sdk/client-s3";
import { ECSClient } from "@aws-sdk/client-ecs";
export declare const s3Client: S3Client;
export declare const ecsClient: ECSClient;
//# sourceMappingURL=s3-utils.d.ts.map