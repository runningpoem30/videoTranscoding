export {};
//# sourceMappingURL=test-signer.d.ts.map