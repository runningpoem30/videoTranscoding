/**
 * Local test script for signer.ts Lambda
 *
 * This simulates what happens when the frontend calls the API Gateway
 * to get a presigned S3 upload URL.
 */
import { handler } from './handler/signer.js';
import dotenv from 'dotenv';
dotenv.config();
// Simulate an API Gateway event
const mockEvent = {
    body: JSON.stringify({
        fileName: 'test-video.mp4',
        contentType: 'video/mp4'
    }),
    headers: {},
    httpMethod: 'POST',
    path: '/upload',
    queryStringParameters: null,
    requestContext: {},
    isBase64Encoded: false
};
console.log('📤 Testing Signer Lambda...\n');
console.log('Input:', JSON.parse(mockEvent.body));
console.log('---');
handler(mockEvent)
    .then((response) => {
    console.log('\n✅ Response:');
    console.log('Status:', response.statusCode);
    const body = JSON.parse(response.body);
    console.log('Upload URL:', body.uploadUrl?.substring(0, 100) + '...');
    console.log('S3 Key:', body.key);
    if (response.statusCode === 200) {
        console.log('\n🎉 Signer Lambda works! You can use curl to test the URL:');
        console.log(`curl -X PUT -T yourfile.mp4 "${body.uploadUrl}"`);
    }
})
    .catch((error) => {
    console.error('\n❌ Error:', error);
});
//# sourceMappingURL=test-signer.js.map