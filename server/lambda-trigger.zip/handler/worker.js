import { PutObjectCommand, GetObjectCommand } from "@aws-sdk/client-s3";
import { s3Client } from "../lib/s3-utils.js";
import fs from "fs";
import path from "path";
import { Readable } from "stream";
import { spawn } from "child_process";
async function downloadFromS3(bucket, key, destination) {
    const command = new GetObjectCommand({ Bucket: bucket, Key: key });
    const response = await s3Client.send(command);
    const stream = response.Body;
    return new Promise((resolve, reject) => {
        const fileWriter = fs.createWriteStream(destination);
        stream.pipe(fileWriter);
        fileWriter.on('finish', resolve);
        fileWriter.off('error', reject);
    });
}
async function transcodingRawS3Video(inputPath, outputDir) {
    return new Promise((resolve, reject) => {
        const ffmpeg = spawn('ffmpeg', [
            '-i', inputPath,
            // Simple single-stream for debugging
            '-c:v', 'libx264', '-b:v', '1000k',
            '-c:a', 'aac', '-b:a', '128k',
            '-f', 'hls',
            '-hls_time', '10',
            '-hls_playlist_type', 'vod',
            '-hls_segment_filename', `${outputDir}/segment_%03d.ts`,
            `${outputDir}/index.m3u8`,
        ], { stdio: 'inherit' }); // <--- See FFmpeg logs in CloudWatch
        ffmpeg.on('close', (code) => {
            if (code === 0)
                resolve(null);
            else
                reject(`ffmpeg failed with code ${code}`);
        });
    });
}
async function uploadFolderToS3(localDirPath, s3Bucket, s3Prefix) {
    const items = fs.readdirSync(localDirPath);
    for (const item of items) {
        const localPath = path.join(localDirPath, item);
        const s3Key = path.join(s3Prefix, item);
        if (fs.statSync(localPath).isDirectory()) {
            await uploadFolderToS3(localPath, s3Bucket, s3Key);
        }
        else {
            const fileStream = fs.createReadStream(localPath);
            await s3Client.send(new PutObjectCommand({
                Bucket: s3Bucket,
                Key: s3Key,
                Body: fileStream,
                ContentType: s3Key.endsWith('.m3u8') ? 'application/x-mpegURL' : 'video/MP2T'
            }));
        }
    }
}
async function run() {
    const BUCKET = process.env.S3_BUCKET;
    const KEY = process.env.S3_KEY;
    const DEST_BUCKET = process.env.DEST_BUCKET;
    const inputPath = '/tmp/input_video.mp4';
    const outputDir = '/tmp/output';
    try {
        // Create output directory and variant subdirectories for HLS segments
        fs.mkdirSync(outputDir, { recursive: true });
        for (let i = 0; i < 5; i++) {
            fs.mkdirSync(`${outputDir}/v${i}`, { recursive: true });
        }
        console.log("Stage 1: Downloading...");
        await downloadFromS3(BUCKET, KEY, inputPath);
        console.log("Stage 2: Transcoding...");
        await transcodingRawS3Video(inputPath, outputDir);
        console.log("Stage 3: Uploading to new bucket...");
        const folderName = path.parse(KEY).name;
        await uploadFolderToS3(outputDir, DEST_BUCKET, `processed/${folderName}`);
        console.log("SUCCESS: Video is now live!");
    }
    catch (err) {
        console.error("FAILED:", err);
        process.exit(1);
    }
}
run();
//# sourceMappingURL=worker.js.map