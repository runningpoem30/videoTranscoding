export declare const handler: (event: any) => Promise<void>;
//# sourceMappingURL=trigger.d.ts.map