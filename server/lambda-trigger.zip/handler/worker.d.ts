export {};
//# sourceMappingURL=worker.d.ts.map